﻿namespace TennisCourtBookingSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateBookingsTable1 : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Bookings", "CreatedAt");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Bookings", "CreatedAt", c => c.DateTime(nullable: false));
        }
    }
}
