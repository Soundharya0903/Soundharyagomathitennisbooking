﻿namespace TennisCourtBookingSystem.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using TennisCourtBookingSystem.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<TennisCourtBookingSystem.Models.TennisDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(TennisCourtBookingSystem.Models.TennisDbContext context)
        {
            if (!context.Users.Any(u => u.Role == "Admin"))
            {
                context.Users.Add(new User
                {
                    Name = "Administrator",
                    Email = "admin@tennis.com",
                    Password = "Admin@123",  // Use hashing in real apps
                    Role = "Admin"
                });
                context.SaveChanges();
            }
        }

    }
}
