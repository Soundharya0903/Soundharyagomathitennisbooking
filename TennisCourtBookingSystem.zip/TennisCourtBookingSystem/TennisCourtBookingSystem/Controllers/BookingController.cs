﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using TennisCourtBookingSystem.Filters;
using TennisCourtBookingSystem.Models;

namespace TennisCourtBookingSystem.Controllers
{
    [NoCache]
    public class BookingController : Controller
    {
        private TennisDbContext db = new TennisDbContext();

        // Full list of time slots
        private List<string> GetAllSlots()
        {
            return new List<string>
            {
                "8:00 AM - 9:00 AM",
                "9:00 AM - 10:00 AM",
                "10:00 AM - 11:00 AM",
                "11:00 AM - 12:00 PM",
                "12:00 PM - 1:00 PM",
                "1:00 PM - 2:00 PM",
                "2:00 PM - 3:00 PM",
                "3:00 PM - 4:00 PM",
                "4:00 PM - 5:00 PM",
                "5:00 PM - 6:00 PM"
            };
        }

        // Extract starting hour from slot (e.g., "9:00 AM - 10:00 AM" => 9)
        private int GetSlotStartHour(string timeSlot)
        {
            var startTimePart = timeSlot.Split('-')[0].Trim();
            if (DateTime.TryParse(startTimePart, out DateTime startTime))
            {
                return startTime.Hour;
            }
            return -1; // fallback
        }

        // Get available slots for a selected date
        private SelectList GetAvailableSlots(DateTime date)
        {
            var allSlots = GetAllSlots();

            var bookedSlots = db.Bookings
                                .Where(b => b.BookingDate == date)
                                .Select(b => b.TimeSlot)
                                .ToList();

            // Remove booked slots
            var availableSlots = allSlots.Except(bookedSlots).ToList();

            // If booking date is today, filter past slots
            if (date.Date == DateTime.Today)
            {
                DateTime now = DateTime.Now;
                availableSlots = availableSlots
                    .Where(slot => GetSlotStartHour(slot) > now.Hour)
                    .ToList();
            }

            return new SelectList(availableSlots);
        }

        // GET: Booking/Create
        public ActionResult Create(DateTime? bookingDate)
        {
            if (Session["UserId"] == null)
                return RedirectToAction("Login", "Account");

            var dateToUse = bookingDate ?? DateTime.Now.Date;

            ViewBag.AvailableSlots = GetAvailableSlots(dateToUse);
            ViewBag.SelectedDate = dateToUse.ToString("yyyy-MM-dd");

            var bookedSlots = db.Bookings
                                .Where(b => b.BookingDate == dateToUse)
                                .Select(b => b.TimeSlot)
                                .ToList();

            ViewBag.BookedSlots = bookedSlots;

            return View();
        }


        // POST: Booking/Create
        [HttpPost]
        public ActionResult Create(DateTime bookingDate, string timeSlot)
        {
            if (Session["UserId"] == null)
                return RedirectToAction("Login", "Account");

            int userId = (int)Session["UserId"];

            if (bookingDate.Date < DateTime.Now.Date)
            {
                ViewBag.Message = "Cannot book for past dates.";
                ViewBag.AvailableSlots = GetAvailableSlots(bookingDate);
                ViewBag.SelectedDate = bookingDate.ToString("yyyy-MM-dd");
                return View();
            }

            // Check if slot already booked
            bool isBooked = db.Bookings.Any(b => b.BookingDate == bookingDate && b.TimeSlot == timeSlot);
            if (isBooked)
            {
                ViewBag.Message = "Slot already booked.";
                ViewBag.AvailableSlots = GetAvailableSlots(bookingDate);
                ViewBag.SelectedDate = bookingDate.ToString("yyyy-MM-dd");
                return View();
            }

            // Check if slot time already passed (for today)
            if (bookingDate.Date == DateTime.Today)
            {
                int slotHour = GetSlotStartHour(timeSlot);
                if (slotHour <= DateTime.Now.Hour)
                {
                    ViewBag.Message = "This slot has already passed.";
                    ViewBag.AvailableSlots = GetAvailableSlots(bookingDate);
                    ViewBag.SelectedDate = bookingDate.ToString("yyyy-MM-dd");
                    return View();
                }
            }

            // Save booking
            Booking booking = new Booking
            {
                UserId = userId,
                BookingDate = bookingDate,
                TimeSlot = timeSlot
            };

            db.Bookings.Add(booking);
            db.SaveChanges();

            ViewBag.Message = "Booking successful!";
            ViewBag.AvailableSlots = GetAvailableSlots(bookingDate);
            ViewBag.SelectedDate = bookingDate.ToString("yyyy-MM-dd");
            return View();
        }
    }
}
