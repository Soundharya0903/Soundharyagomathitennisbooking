﻿using System.Collections.Generic;

namespace TennisCourtBookingSystem.Models
{
    public class AdminDashboardViewModel
    {
        public List<User> Users { get; set; }
        public List<Booking> Bookings { get; set; }
        public string SearchTerm { get; set; }
    }
}
