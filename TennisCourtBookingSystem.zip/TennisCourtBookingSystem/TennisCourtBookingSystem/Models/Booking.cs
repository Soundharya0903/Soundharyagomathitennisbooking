﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TennisCourtBookingSystem.Models
{
    public class Booking
    {
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime BookingDate { get; set; }

        [Required]
        public string TimeSlot { get; set; } // e.g., "8:00 AM - 9:00 AM"

        public virtual User User { get; set; }
    }
}
