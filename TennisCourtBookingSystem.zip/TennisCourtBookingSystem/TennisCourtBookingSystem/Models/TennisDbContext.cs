﻿using System.Collections.Generic;
using System.Data.Entity;

namespace TennisCourtBookingSystem.Models
{
    public class TennisDbContext : DbContext
    {
        public TennisDbContext() : base("TennisDbContext") { }

        public DbSet<User> Users { get; set; }
        public DbSet<Booking> Bookings { get; set; }

    }

}
